<?php

/*
 * All database connection variables
 */

define('DB_USER',"admin_ads"); // db user
define('DB_PASSWORD',"9828430020"); // db password (mention your db password here)
define('DB_DATABASE',"admin_ads"); // database name
define('DB_SERVER',"localhost"); // db server
?>
